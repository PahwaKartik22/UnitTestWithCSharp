﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TriangleSolver;
using NUnit.Framework;

namespace TestTriangleSolver
{
    [TestFixture]
    public class Class1
    {
        //Test-1
        //Test for equilateral traingle
        [Test]
        public void ValidTriangle_Input4and4and4_OutputEquilateralTriangle()
        {
            Triangle triangle = new Triangle();
            int firstSide = 4;
            int secondSide = 4;
            int thirdSide = 4;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            Assert.AreEqual(expected, actual);
        }

        //Test-2
        //Test for Isosceles traingle - 1st
        [Test]
        public void ValidTriangle_Input6and6and3_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            int firstSide = 6;
            int secondSide = 6;
            int thirdSide = 3;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            Assert.AreEqual(expected, actual);
        }

        //Test-3
        //Test for Isosceles traingle - 2nd
        [Test]
        public void ValidTriangle_Input13and1and13_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            int firstSide = 13;
            int secondSide = 1;
            int thirdSide = 13;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            Assert.AreEqual(expected, actual);
        }

        //Test-4
        //Test for Isosceles traingle - 3rd
        [Test]
        public void ValidTriangle_Input9and7and7_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            int firstSide = 9;
            int secondSide = 7;
            int thirdSide = 7;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            Assert.AreEqual(expected, actual);
        }

    }
}
